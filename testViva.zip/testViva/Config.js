const Config = {
    Server: {
        API_BASE_URL: 'https://viva.vianova.ai/api'
    }
}

export default Config;