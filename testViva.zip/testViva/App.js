import React from 'react';
import Store from "./src/Store";
import { Provider } from 'react-redux';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import SplashScreen from "./src/screens/SplashScreen";
import LoginScreen from "./src/screens/LoginScreen";
import HomeScreen from "./src/screens/HomeScreen";
import TestScreen from './src/screens/TestScreen';
import ProductDetails from "./src/screens/ProductDetails";
import ProductByCategory from "./src/screens/ProductByCategory";
import ProfileScreen from "./src/screens/ProfileScreen";
import { BottomTab } from './src/navigation/BottomTabNavigation';
export default function App() {
	const Stack = createStackNavigator();

	return (
		<Provider store={Store}>
            <View style={Styles.appContainer}>
                <StatusBar hidden></StatusBar>
                <NavigationContainer>
                    <Stack.Navigator 
                        initialRouteName="SplashScreen"
                        screenOptions={{gestureEnabled: false}}
                        headerMode="none"
                    >
                        <Stack.Screen name="SplashScreen" component={SplashScreen} />
                        <Stack.Screen name="LoginScreen" component={LoginScreen} />
                        <Stack.Screen name="HomeScreen" component={HomeScreen} />
                        <Stack.Screen name="TestScreen" component={TestScreen}/>
                        <Stack.Screen name="ProductDetails" component={ProductDetails}/>
                        <Stack.Screen name="ProductByCategory" component={ProductByCategory}/>
                        <Stack.Screen name="ProfileScreen" component={ProfileScreen}/>
                    </Stack.Navigator>
                </NavigationContainer>
            </View>
        </Provider>
	);
}

const Styles = StyleSheet.create({
    appContainer: {
        flex: 1
    }
})