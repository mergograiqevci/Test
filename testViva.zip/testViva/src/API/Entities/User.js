import Request from "../../API/Request";
import UserActions from "../../Store/User/Actions";
class User {
    
    static async login(email, password) {
        let userData = 
            await Request.post(
                `/auth/login`,
                {
                    email,
                    password
                }
            );
        return userData;
    }
    static async userProfileData()
    {
        const token=await UserActions.getLocalToken();
        let userData=
            await Request.get(`/auth/me`,{
                headers:{
                    Authorization:`Bearer ${token}`
                }
            })
        return userData;
    }
}

export default User;