import React from "react";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { TouchableOpacity } from "react-native";
import SplashScreen from "../screens/SplashScreen";
import ProductDetails from "../screens/ProductDetails";
import SearchScreen from "../screens/SearchScreen";
import LoginScreen from "../screens/LoginScreen";
import HomeScreen from "../screens/HomeScreen";
import ProductByCategory from "../screens/ProductByCategory";
import ProfileScreen from "../screens/ProfileScreen";
import {Foundation,AntDesign,Ionicons} from "@expo/vector-icons";
const Tab = createBottomTabNavigator();
const BottomTab = ()=> {
  return (
    <Tab.Navigator
        initialRouteName="Feed"
        tabBarOptions={{
            activeTintColor:'red',
            style:{
                borderTopLeftRadius: 40,
                borderTopRightRadius: 40,
                height: 100,
                borderWidth:1,
                borderColor:'silver',
            },
            activeTabStyle: {
              borderWidth:1,
              borderColor:'red'
            }
        }}
    >
        <Tab.Screen 
        name="SplashScreen" 
        component={SplashScreen}
        options={{
            tabBarButton: TopLine,
            tabBarLabel: 'Ballina',
            tabBarIcon: () => (
                <Foundation name="home" color="silver" size={30} />
            ),
            }}
        />
        <Tab.Screen 
            name="Favorite" 
            component={ProductByCategory}
            options={{
                tabBarButton: TopLine,
                tabBarLabel: 'Favoritet',
                tabBarIcon: () => (
                <AntDesign name="hearto" color="silver" size={30} />
                ),
            }}
        />
        <Tab.Screen 
            name="ProductDetails" 
            component={ProductDetails}
            options={{
                tabBarButton: TopLine,
                tabBarLabel: 'Shporta',
                tabBarIcon: () => (
                <Ionicons name="cart-outline" color="silver" size={30} />
                ),
            }}
        />
        <Tab.Screen 
            name="LoginScreen" 
            component={LoginScreen}
            options={{
                tabBarButton: TopLine,
                tabBarLabel: 'Profili',
                tabBarIcon: () => (
                <AntDesign name="user" color="silver" size={30} />
                ),
            }}
        />
         <Tab.Screen 
            name="ProfileScreen" 
            component={ProfileScreen}
            options={{
                tabBarButton: TopLine,
                tabBarLabel: 'Profili',
                tabBarIcon: () => (
                <AntDesign name="user" color="silver" size={30} />
                ),
            }}
        />
    </Tab.Navigator>
  );
}
const TopLine = (props) => (
    <TouchableOpacity
      {...props}
      style={
        props.accessibilityState.selected
          ? [props.style, { borderTopColor: 'red', borderTopWidth: 3 ,marginLeft:30,marginRight:30,maxWidth:70}]
          : props.style
      }
    />
  );
export {BottomTab};