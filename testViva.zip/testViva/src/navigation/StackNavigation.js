import React from "react";
import { createStackNavigator } from '@react-navigation/stack';

import SplashScreen from "../screens/SplashScreen";
import ProductDetails from "../screens/ProductDetails";
import SearchScreen from "../screens/SearchScreen";
import LoginScreen from "../screens/LoginScreen"
const Stack = createStackNavigator();

const Home = () =>{
  return (
    <Stack.Navigator>
      <Stack.Screen name="Home" component={LoginScreen} />
      <Stack.Screen name="Splash" component={SplashScreen} />
    </Stack.Navigator>
  );
}
export {Home};