import { createSlice } from '@reduxjs/toolkit';

import State from "../../Store/State";
const initialState = {
    data: null,
    profileData: null,
    loginError: null,
    dataState: State.NOT_PROCESSED,
    isAdmin:false,
    isSimpleUser:false,
    token:null
};

const slice = createSlice({
    name: 'User',
    initialState,
    reducers: {
        loginStart(state) {
            state.dataState = State.PROCESSING;
        },
        loginDone(state, action) {
            state.data = action.payload;
            state.dataState = State.DONE;
        },
        loginFailed(state, action) {
            state.loginError = action.payload;
            state.dataState = State.FAILED;
        },
        isSimpleUser(state,action)
        {
            state.isSimpleUser=action.payload;
        },
        isAdminAndUser(state,action)
        {
            state.isSimpleUser=action.payload;
            state.isAdmin=action.payload;
        },
        setUserProfile(state,action)
        {
            state.profileData=action.payload;
        },
        setToken(state,action)
        {
            state.token=action.payload;
        }
    }
});

export const UserSlice = slice;
export const {
    loginStart,
    loginDone,
    loginFailed,
    isSimpleUser,
    isAdminAndUser,
    setUserProfile,
    setToken
} = slice.actions;
