import * as API from "../../API"
import * as UserReducers from './Reducers';
import AsyncStorage from '@react-native-async-storage/async-storage';
class UserActions {

    static login(username, password) {
        return (dispatch) => {
            dispatch(UserReducers.loginStart());
            API.User.login(username, password)
            .then(data => {
                this.saveLocalToken(data.data.token);
                dispatch(UserReducers.loginDone(data));
            })
            .catch(error => {
                dispatch(UserReducers.loginFailed(error));
            })
        };  
    }
    static userProfileData() {
        return (dispatch) => {
            API.User.userProfileData()
            .then(data => {
                dispatch(UserReducers.setUserProfile(data));
            })
            .catch(error => {
                //dispatch(UserReducers.loginFailed(error));
            })
        };  
    }
    static setTokenToRedux(asyncToken) {
        return (dispatch) => {
            dispatch(UserReducers.setToken(asyncToken));
        };  
    }
    static logout()
    {
        this.clearLocalToken();
    }
    static saveLocalToken = async (value) => {
        try {
            await AsyncStorage.setItem('token', value)
            
        } catch (e) {
            //console.log(e);
        }
    }
    static getLocalToken = async () => {
        try {
          return await AsyncStorage.getItem('token');
        } catch(e) {
            //console.log(e);
            return "error";
        }
    }
    static clearLocalToken = async() => {
        await AsyncStorage.removeItem('token');
    }
    static isSimpleUser() {
        return (dispatch) => {
            dispatch(UserReducers.isSimpleUser(true));
        };  
    }
    static isAdminAndUser() {
        return (dispatch) => {
            dispatch(UserReducers.isAdminAndUser(true));
        };  
    }
}

export default UserActions;