const State = {
    NOT_PROCESSED: "NOT_PROCESSED",
    PROCESSING: "PROCESSING",
    DONE: "DONE",
    FAILED: "FAILED",
}

export default State;