const Images = {
    Background:require('../../assets/background.png')
};
export default Images;