import React,{useEffect}from 'react';
import { View ,ImageBackground} from 'react-native';
import Styles from './styles';
import Images from './Images';
import UserActions from "../../Store/User/Actions";
import { useDispatch } from 'react-redux';
const SplashScreen = (props) => {
    const dispatch=useDispatch();
    useEffect(()=>{
        setTimeout(() => {
            autoLogin();
        },2000);
    },[])
    const autoLogin = async () =>{
        const token=await UserActions.getLocalToken();
        dispatch(UserActions.setTokenToRedux(token));
        if(token)
        {
            props.navigation.replace("ProfileScreen");
        }
        else{
            props.navigation.replace("LoginScreen");
        }
    }
    return (
        <View style={Styles.container}>
            <ImageBackground source={Images.Background} resizeMode="cover" style={Styles.image}>
            </ImageBackground>
        </View>
    );
}

export default SplashScreen;