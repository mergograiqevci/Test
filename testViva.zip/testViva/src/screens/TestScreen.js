import React,{useState}from "react";
import { TextInput ,Text,Button,View} from "react-native";
import AsyncStorage from '@react-native-async-storage/async-storage';
import UserActions from "../Store/User/Actions";
import { useSelector,useDispatch} from "react-redux";
const TestScreen = () =>{
    //const dispatch = useDispatch();
    //setResponse(UserActions.getAsyncStorageData());
    const dispatch=useDispatch();
    const token=useSelector(state=>state.User.token);
    const[response,setResponse]=useState("");
    const handleToken = async () =>{
        dispatch(UserActions.setTokenToRedux("qweq"));
    }
    const readToken = async () =>{
        //const token=await UserActions.getLocalToken();
        setResponse(token);
    }
    const removeToken = async () =>{
        dispatch(UserActions.clearLocalToken());
    }
    return (
        <View style={{marginTop:150}}>
            <Text>{response}</Text>
            <Button title="Write" onPress={handleToken}/>
            <Button title="Read" onPress={readToken}/>
            <Button title="remove" onPress={removeToken}/>
        </View>
    );
}
export default TestScreen;