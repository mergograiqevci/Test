import React, { useState } from 'react';
import { Text, TextInput, View } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import UserActions from "../../Store/User/Actions";
import State from '../../Store/State';
import LoginForm from "../../components/LoginForm"
import Styles from './styles';

const LoginScreen = (props) => {

    const dispatch = useDispatch();
    const userData = useSelector(state => state.User);
    const isAdmin = useSelector(state=>state.User.isAdmin);
    const token=useSelector(state=>state.User.token1);
    const isSimpleUser = useSelector(state=>state.User.isSimpleUser);
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const handleLoginPressed = () => {
        //id = userData.data.data.user.id 
        //tokeni = userData.data.data.token
        //roles= userData.data.data.user.roles
        dispatch(UserActions.login(username, password));
        //const roles=userData.data.data.user.roles;
        const roles="user";// admin,user
        if(roles)
        {
            console.log(token);
            if(roles.toLowerCase().includes("admin") && roles.toLowerCase().includes("user"))
            {
                console.log("Osht admin dhe user");
                dispatch(UserActions.isAdminAndUser())
            }
            if(roles.toLowerCase().includes("user") && !roles.toLowerCase().includes("admin"))
            {
                console.log("osht user")
                dispatch(UserActions.isSimpleUser())
            }
        }
    }
    return (
        <View style={Styles.container}>
            <LoginForm 
                onChangeUsernameText={value=>setUsername(value)}
                onChangePasswordText={value=>setPassword(value)}
                onLoginButtonPress={handleLoginPressed}
                errorMessage={userData.dataState === State.FAILED ? "Emri Apo Password eshte gabim!" : null}
            />
        </View>
    );
}

export default LoginScreen;