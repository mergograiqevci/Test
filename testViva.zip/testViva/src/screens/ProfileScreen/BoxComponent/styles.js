import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container:{
        marginTop:10,
        marginHorizontal:20,
    },
    box:{
        justifyContent:'space-between',
        margin:5,
        borderWidth:1,
        flex:1/2,
        paddingHorizontal:10,
        borderRadius:10,
        height:110
    },
    titleView:{
        borderBottomWidth:1,
        borderBottomColor:"black",
    },
    titleText:{
        fontSize:15,
        fontWeight:'bold'
    },
    countText:{
        fontSize:30,
        fontWeight:'bold',
    },
    typeText:{
        fontSize:15
    }
});