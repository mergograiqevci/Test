import React from "react";
import {View ,Text,FlatList} from "react-native";
import Styles from "./styles";
const BoxComponent = ({data}) =>{
    console.log(data);
    return (
        <View style={Styles.container}>
            <FlatList
                data={data}
                keyExtractor={count=>count.toString()}
                numColumns={2}
                renderItem={({item})=>{
                    return (
                        <View style={Styles.box}>
                            <View style={Styles.titleView}>
                                <Text style={Styles.titleText}>{item.title}</Text>
                            </View>
                            <Text style={Styles.countText}>{item.count}</Text>
                            <Text style={Styles.typeText}>{item.type}</Text>
                        </View>
                    )
                }}
            />            
        </View>
    )
}
export default BoxComponent;