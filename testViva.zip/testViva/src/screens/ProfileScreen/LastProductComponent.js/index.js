import React from "react";
import {Text,View,ImageBackground} from "react-native";
import { EvilIcons ,AntDesign} from "@expo/vector-icons";
import Styles from "./styles";
const LastProductComponent=()=>{
    return (
        <View style={Styles.container}>
            <ImageBackground source={{uri:"https://vfs.vianova.ai/_nuxt/img/bg.7f37586.png"}} style={Styles.imageBackground}>
                <View style={Styles.lastOrderProductTextView}>
                    <Text style={Styles.lastOrderText}>Porosia e fundit</Text>
                    <Text style={Styles.seeAllOrderText}>SHIKO TE GJITHA</Text>
                </View>
                <View style={Styles.orderDetailsView}>
                    <View style={Styles.streetView}>
                        <EvilIcons name="location" color="red" size={30}/>
                        <Text>Muharrem Fejza,Mati1,Royal B1</Text>
                    </View>
                    <View style={Styles.fullCartDetails}>
                        <View style={Styles.shoppingCartView}>
                            <AntDesign name="shoppingcart" color="red" size={45}/>
                        </View>
                        <View style={Styles.orderDetails}>
                            <View>
                                <Text>Id e porosise</Text>
                                <Text>214132</Text>
                            </View>
                            <View>
                                <Text>Statusi</Text>
                                <Text>PAKETUAR</Text>
                            </View>
                        </View>
                    </View>
                    <View style={Styles.priceView}>
                        <Text style={Styles.totalPriceText}>Total</Text>
                        <Text style={Styles.totalPrice}>9.00E</Text>
                    </View>
                </View>
            </ImageBackground>
        </View>
    );
}
export default LastProductComponent;