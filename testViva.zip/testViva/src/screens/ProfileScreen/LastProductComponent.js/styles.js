import { StyleSheet ,Dimensions} from "react-native";
const {width}=Dimensions.get("window");
export default StyleSheet.create({
    container:{
        margin:25,
        
    },
    orderDetailsView:{
        borderWidth:1
    },
    lastOrderProductTextView:{
        flexDirection:'row',
        justifyContent:'space-between',
        marginVertical:10
    },  
    lastOrderText:{
        fontSize:15,
        fontWeight:'bold'
    },
    seeAllOrderText:{
        fontSize:13,
        fontWeight:'bold',
        color:'red'
    },
    streetView:{
        flexDirection:'row',
        alignItems:'center',
        justifyContent:'center',
        borderBottomWidth:1,
        borderBottomColor:'black',
        padding:10
    },
    shoppingCartView:{
        borderWidth:1,
        width:90,
        height:90,
        alignItems:'center',
        justifyContent:'center',
        borderRadius:10
    },
    orderDetails:{
        flexDirection:'row',
        justifyContent:'space-between'
    },
    fullCartDetails:{
        flexDirection:'row',
        marginVertical:20,
        borderBottomColor:"black",
        padding:10,
        paddingHorizontal:15,
        borderBottomWidth:1
    },
    priceView:{
        flexDirection:'row',
        justifyContent:'space-between',
        marginHorizontal:15,
        marginVertical:10
    },
    totalPriceText:{
        fontSize:16,
        fontWeight:'bold'
    },
    totalPrice:{
        fontSize:16,
        fontWeight:'bold',
        color:'red'
    },
    imageBackground: {
        flex: 1,
        resizeMode: 'cover',
        justifyContent: 'center'
    },
});