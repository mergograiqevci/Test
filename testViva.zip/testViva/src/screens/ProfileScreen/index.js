import React,{useEffect}from "react";
import { View,Text, } from "react-native";
import { useDispatch ,useSelector} from "react-redux";
import {FontAwesome5,AntDesign,SimpleLineIcons} from "@expo/vector-icons";
import UserActions from "../../Store/User/Actions";
import BoxComponent from "./BoxComponent";
import LastProductComponent from "./LastProductComponent.js";
import Styles from "./styles";
const ProfileScreen = () =>{
    const dispatch=useDispatch();
    const userData=useSelector(state=>state.User.profileData);
    //console.log(userData);
    useEffect(()=>{
        //dispatch(UserActions.userProfileData());
    },[])
    const arrTest=[
        {
        title:"Blerje kete muaj",
        count:"6937",
        type:"Produkte te blera"
        },
        {
        title:"Zbritjet kete muaj",
        count:"597",
        type:"Detaje te statistikes"
        }
    ];
    return (
        <View style={{flex:1}}>
            <View style={Styles.upperProfileData}>
                <View style={Styles.nameNumberView}>
                    <Text style={Styles.fullNameText}>Patrik Leci</Text>
                    <Text style={Styles.phoneNumberText}>+38344953980</Text>
                </View>
                <View style={Styles.iconView}>
                    <FontAwesome5 name="medal" color="orange" size={30} style={Styles.iconView}/>
                </View>
            </View>
            <View>
                <View style={Styles.fillData}>
                    <View style={Styles.creditCardView}>
                        <AntDesign name="creditcard" color="black" size={25}/>
                        <Text style={Styles.fillDataText}>Ploteso te dhenat</Text>
                    </View>
                    <AntDesign name="right" color="black" size={25}/>
                </View>
                <View style={Styles.logoutView}>
                    <SimpleLineIcons name="logout" color="black" size={25}/>
                    <Text style={Styles.logoutText}>Log out</Text>
                </View>
            </View>
            <BoxComponent 
                data={arrTest}
            />
            <LastProductComponent />
        </View>
    );
}
export default ProfileScreen;