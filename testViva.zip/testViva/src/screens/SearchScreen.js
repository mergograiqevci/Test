import React,{useState,useEffect}from "react";
import SearchBar from "../components/SearchBar";
const SearchScreen = () =>{
    const [searchTerm,setSearchTerm]=useState("");
    useEffect(()=>{
        
      },[searchTerm]);
    return (
        <>
        <SearchBar 
            onTermChange={newTerm=>setSearchTerm(newTerm)}
        />
        </>
    )
}
export default SearchScreen;