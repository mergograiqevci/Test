import React from 'react';
import {View, Button, StyleSheet, ImageBackground} from 'react-native';
import ProductBox from '../components/ProductBox';
import UserActions from '../Store/User/Actions';
const HomeScreen =(props)=>{
  const image = {uri: 'https://vfs.vianova.ai/_nuxt/img/bg.7f37586.png'};
  const handleRemoveToken = async ()=>{
    await UserActions.clearLocalToken();
    props.navigation.navigate("SplashScreen");
  }
  return (
    <View style={styles.container}>
      <Button title="REMOVE" onPress={handleRemoveToken}/>
      <ImageBackground
        source={image}
        resizeMode="cover"
        style={styles.backgroundImage}>
            <ProductBox viewMode="vertical"/>
      </ImageBackground>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop:100
  },
  headerComponent: {
    display: 'flex',
    alignItems: 'flex-start',
    marginTop: 70,
    marginLeft: 20,
    marginRight: 20,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  subHeaderText: {
    fontSize: 13,
    paddingTop: 10,
    opacity: 0.5,
  },
  headerBoxComponents: {
    marginTop: 20,
    display: 'flex',
    flexDirection: 'row',
  },
  backgroundImage: {
    flex: 1,
  },
  productContainerHeaderText: {
    marginTop: 20,
    marginBottom: -7,
    fontSize: 16,
    fontWeight: 'bold',
  },

  productContainerHeader: {
    justifyContent: 'center',
    alignSelf: 'center',
  },
  productTypes: {
    padding: 10,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },

  productBox: {
    alignItems: 'center',
    flexDirection: 'row',
    margin: 10,
    display: 'flex',
  },
});

export default HomeScreen;