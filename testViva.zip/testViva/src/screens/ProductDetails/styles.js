import { StyleSheet,Dimensions } from "react-native";
const {width}=Dimensions.get("window");
export default StyleSheet.create({
    container:{
        flex:1,
        alignItems:'center',
        marginTop:width/9,
    },
    image: {
        flex: 1,
        resizeMode: 'cover'
      },
    category:{
        fontSize:15
    },
    productName:{
        fontSize:20,
        fontWeight:'bold'
    },
    productPriceView:{
        flexDirection:'row',
        marginBottom:15
    },
    productPriceWithDiscount:{
        alignSelf:'center',
        fontSize:25,
        fontWeight:'bold',
        color:'#FF0000',
        marginRight:10,
    },
    productPriceWithoutDiscount:{
        alignSelf:'center',
        fontSize:15,
        textDecorationLine: 'line-through',
        color:'#FC4B4B',
        marginRight:10
    },
    imageView:{
        width:330,
        alignItems:'center',
        backgroundColor:'#fff',
        borderRadius:10,
        padding:10,
        marginBottom:15
    },
    img:{
        height:350,
        width:170
    },
    productDetails:{
        margin:10
    },
    productDetailsTitle:{
        textAlign:'center',
        fontSize:18,
        fontWeight:'bold'
    },
    productDetailsBody:{
        padding:10
    },
    addInBagButton:{
        alignSelf:'stretch',
        alignItems:'center',
        justifyContent:'center',
        height:60,
        backgroundColor:'#FF0000',
        borderRadius:15,
        margin:15
    },
    addInBagButtonText:{
        fontSize:15,
        color:'white',
        fontWeight:'bold',
    },
    increaseDecreaseItem:{
        alignSelf:'stretch',
        flexDirection:'row',
        justifyContent:'space-between',
        margin:10,
        padding:5
    },
    productBagWeight:{
        alignSelf:'center'
    },
    priceItems:{
        fontSize:15,
        fontWeight:'bold',
        color:'#FF0000',
        alignSelf:'center'
    },
    productBox: {
        alignItems: 'center',
        flexDirection: 'row',
        margin: 10,
        display: 'flex',
      },
});