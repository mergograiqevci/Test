import React,{useState} from "react";
import {Text,View,Image,TouchableOpacity,ScrollView,ImageBackground} from "react-native";
import ProductQuantity from "../../components/ProductQuantity"
import ProductBox from "../../components/ProductBox";
import HeaderProductDetails from "../../components/HeaderProductDetails";
import Styles from "./styles";
const arrList = 
    {
        id:3,
        category:"OIL",
        productName:"Organic Glute-Free Rolled Oats",
        productPriceWithDiscount:"4.30",
        productPriceWithoutDiscount:"5.00",
        productImage:"https://images-na.ssl-images-amazon.com/images/I/61BK5x%2B-qtL._SL1440_.jpg",
        productBagWeight:"32",
        productDetailsTitle:"Pershkrimi i Produktit",
        productDetailsBody:"Edible oil is a fatty liquid that is physically extracted from several vegetables and also some animal tissues, the most appreciated being olive oil for both taste and health properties (Preedy and Watson, 2010)"
    };

const ProductDetails = () =>{  
    const [currentProductPrice,setCurrentProductPrice]=useState(parseFloat(arrList.productPriceWithDiscount));
    const [countProduct,setCountProduct]=useState(1);
    return(
        <ImageBackground source={{uri:"https://vfs.vianova.ai/_nuxt/img/bg.7f37586.png"}} style={Styles.image}>
            <ScrollView>
                <View style={Styles.container}>
                    <HeaderProductDetails />
                    <Text style={Styles.category}>Kategoria:{arrList.category}</Text>
                    <Text style={Styles.productName}>{arrList.productName}</Text>
                    <View style={Styles.productPriceView}>
                        <Text style={Styles.productPriceWithDiscount}>{arrList.productPriceWithDiscount}<Text style={{fontSize:29}}>€</Text></Text>
                        <Text style={Styles.productPriceWithoutDiscount}>{arrList.productPriceWithoutDiscount}<Text style={{fontSize:19}}>€</Text></Text>
                    </View>
                    <View style={Styles.imageView}>
                        <Image
                            style = {Styles.img} 
                            source={{uri:arrList.productImage}}/>
                    </View>
                    <View style={Styles.increaseDecreaseItem}>
                        <Text style={Styles.productBagWeight}>{arrList.productBagWeight} oz bag</Text>
                        <ProductQuantity 
                            productPrice={arrList.productPriceWithDiscount}
                            currentPrice={currentProductPrice}
                            setCurrentPrice={value=>setCurrentProductPrice(value)}
                            countItem={countProduct}
                            setCountItem={value=>setCountProduct(value)}
                        />
                        <Text style={Styles.priceItems}>{currentProductPrice}<Text style={{fontSize:18}}>€</Text></Text>
                    </View>
                    <View Styles={Styles.productDetails}>
                        <Text style={Styles.productDetailsTitle}>{arrList.productDetailsTitle}</Text>
                        <Text style={Styles.productDetailsBody}>{arrList.productDetailsBody}</Text>
                    </View>
                    <TouchableOpacity style={Styles.addInBagButton}>
                        <Text style={Styles.addInBagButtonText}>SHTOJE NE SHPORTE</Text>
                    </TouchableOpacity>
                </View>
                <ProductBox viewMode="horizontal"/>
            </ScrollView>
        </ImageBackground>
    )
}
export default ProductDetails;