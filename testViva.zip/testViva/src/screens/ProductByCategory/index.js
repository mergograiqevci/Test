import React from "react";
import { Text,View,StyleSheet,ImageBackground,Dimensions,TouchableOpacity} from "react-native";
import ProductBox from "../../components/ProductBox";
import ProductMenuType from "../../components/ProductMenuType";
import HeaderProductByCategory from "../../components/HeaderProductByCategory";
import SortMenu from "../../components/SortMenu";
import Styles from "./styles";
const ProductByCategory = ()=>{
    return(
        <View style={{flex:1}}>
            <View style={Styles.categoryView}>
                <ImageBackground source={{uri:"https://imagesvc.meredithcorp.io/v3/mm/image?url=https%3A%2F%2Fstatic.onecms.io%2Fwp-content%2Fuploads%2Fsites%2F44%2F2021%2F02%2F04%2Fwatercress-salad-honey-Balsamic-tofu-2000.jpg"}} style={Styles.image}>
                    <HeaderProductByCategory />
                </ImageBackground>
            </View>
            <View style={Styles.categoryTitleView}>
                <Text style={Styles.categoryTitle}>Ushqimore</Text>
            </View>
            <View style={{flex:1}}>
                <SortMenu title="Produktet"/>
                <ProductMenuType/>
                <ProductBox viewMode="vertical"/>
            </View>
        </View>
    );
}
export default ProductByCategory;