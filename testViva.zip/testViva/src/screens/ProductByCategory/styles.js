import { StyleSheet ,Dimensions} from "react-native";
const {width}=Dimensions.get("window");
export default StyleSheet.create({
    categoryView:{
        height:300
    },
    categoryTitleView:{
        height:50,
        backgroundColor:'#63C657',
        width:width,
        borderBottomLeftRadius:60,
        borderBottomRightRadius:60,
        alignItems:'center',
        justifyContent:'center'
    },
    categoryTitle:{
        textAlign:'center',
        fontSize:20,
        color:'white',
        fontWeight:'bold'
    },
    image: {
        flex: 1,
        resizeMode: 'cover'
    },

});