import React from "react";
import { ImageBackground ,View,Text,TextInput,TouchableOpacity} from "react-native";
import Styles from "./styles";
const LoginForm = ({onChangeUsernameText,onChangePasswordText,onLoginButtonPress,errorMessage})=>{
    return (
        <View style={Styles.container}>
            <ImageBackground source={require('../../assets/background.png')} style={Styles.image}>
                <View style={Styles.form}>
                    <Text style={Styles.title}>Mireseerdhet ne tregun tone online</Text>
                     { errorMessage ? <Text style={Styles.errorMessage}>{errorMessage}</Text> : null}
                    <Text style={Styles.label}>Emri</Text>
                    <TextInput style={Styles.input}
                        placeholder="Shkruaj ketu"
                        autoCapitalize="none" 
                        autoCorrect={false} 
                        onChangeText={value=>onChangeUsernameText(value)}
                    />
                    <Text style={Styles.label}>Fjalekalimi</Text>
                    <TextInput style={Styles.input}
                        placeholder="Shkruaj ketu"
                        autoCapitalize="none" 
                        autoCorrect={false} 
                        secureTextEntry={true}
                        onChangeText={value=>onChangePasswordText(value)}
                    />
                    <TouchableOpacity style={Styles.loginButton} onPress={()=>onLoginButtonPress()}>
                        <Text style={Styles.loginButtonText}>KYQU</Text>
                    </TouchableOpacity>
                </View>
            </ImageBackground>
      </View>
    );
}


export default LoginForm;