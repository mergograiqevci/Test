import { StyleSheet } from "react-native";
export default StyleSheet.create({
    container: {
      flex: 1,
      flexDirection: 'column'
    },
    image: {
        flex: 1,
        resizeMode: 'cover',
        justifyContent: 'center'
      },
    form:{
        backgroundColor:'#F9F9F9',
        margin:15,
        borderRadius:10,
        paddingHorizontal:15,
        paddingTop:15,
        paddingBottom:30
    },
    title:{
        fontSize:20,
        textAlign:'center',
        marginBottom:5,
        padding:20
    },
    errorMessage:{
        fontSize:15,
        textAlign:'center',
        marginBottom:20,
        color:'red'
    },
    label:{
        marginLeft:10
    },  
    input:{
        borderWidth:1,
        borderColor:'#EEEEEE',
        padding:10,
        borderRadius:13,
        marginVertical:7,
        height:50,
        marginBottom:27
    },
    loginButton:{
        backgroundColor:'#2FB353',
        height:50,
        justifyContent:'center',
        borderRadius:13
    },
    loginButtonText:{
        textAlign:'center',
        color:'white',
        fontWeight:'bold',
        fontSize:15
    
    }
});