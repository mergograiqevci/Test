import React from "react";
import { View ,StyleSheet,Dimensions,TouchableOpacity} from "react-native";
import { AntDesign } from "@expo/vector-icons";

const {width}=Dimensions.get("window");
const HeaderProductDetails = () =>{

    return (
        <View style={styles.view}>
            <TouchableOpacity>
                <AntDesign name="caretleft" color="black" size={30}/>
            </TouchableOpacity>
            <TouchableOpacity>
                <AntDesign name="hearto" color="green" size={30} />
            </TouchableOpacity>
        </View>
    )
}
const styles=StyleSheet.create({
    view:{
        width:width*0.9,
        flexDirection:'row',
        justifyContent:'space-between'
    }
});
export default HeaderProductDetails;