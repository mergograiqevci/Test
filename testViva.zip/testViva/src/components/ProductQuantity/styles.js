import { StyleSheet } from "react-native";

export default StyleSheet.create({
    decreaseItem:{
        width:40,
        height:40,
        borderWidth:1,
        borderColor:'#C3E1E3',
        borderTopLeftRadius:5,
        borderBottomLeftRadius:5,
        alignItems:'center',
        justifyContent:'center',
        backgroundColor:'#fff'
    },
    increaseItem:{
        width:40,
        height:40,
        borderWidth:1,
        borderColor:'#C3E1E3',
        borderTopRightRadius:5,
        borderBottomRightRadius:5,
        alignItems:'center',
        justifyContent:'center',
        backgroundColor:'#fff'
    },
    itemCountText:{
        width:40,
        height:40,
        borderWidth:1,
        borderColor:'#C3E1E3',
        backgroundColor:'#fff',
        alignItems:'center',
        justifyContent:'center'
    }
});