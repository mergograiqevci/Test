import React from "react";
import {View,TouchableOpacity,Text,StyleSheet} from "react-native";
import Styles from "./styles";
const ProductQuantity = ({productPrice,currentPrice,setCurrentPrice,countItem,setCountItem}) =>{

    const handleIncreaseDecrease = (type) =>{
        if(type=="+")
        {
            const results=(parseFloat(currentPrice) + parseFloat(productPrice)).toFixed(2);
            setCountItem(countItem+1);
            setCurrentPrice(results);
        }
        else if(type=="-" && countItem!=1) {
            const results=(parseFloat(currentPrice) - parseFloat(productPrice)).toFixed(2);
            setCountItem(countItem-1);
            setCurrentPrice(results);
        }
    }
    return (
        <View style={{flexDirection:'row'}}>
            <TouchableOpacity style={Styles.decreaseItem} onPress={()=>handleIncreaseDecrease("-")}>
                <Text>-</Text>
            </TouchableOpacity>
            <View style={Styles.itemCountText}>
                <Text >{countItem}</Text>
            </View>
            <TouchableOpacity style={Styles.increaseItem} onPress={()=>handleIncreaseDecrease("+")}>
                <Text>+</Text>
            </TouchableOpacity>
        </View>
    );
}
export default ProductQuantity;