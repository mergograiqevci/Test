import React from "react";
import { View ,StyleSheet,Dimensions,TouchableOpacity,Text} from "react-native";
import { AntDesign } from "@expo/vector-icons";

const {width}=Dimensions.get("window");
const HeaderProductByCategory = () =>{

    return (
        <View style={styles.view}>
            <TouchableOpacity>
                <View style={styles.backIcon}>
                    <AntDesign name="caretleft" color="black" size={25}/>
                </View>
            </TouchableOpacity>
            <TouchableOpacity>
                <View style={styles.filtroTextView}>
                    <Text style={styles.filtroText}>Filtro</Text>
                </View>
            </TouchableOpacity>
        </View>
    )
}
const styles=StyleSheet.create({
    view:{
        width:width*0.9,
        marginTop:width/5,
        flexDirection:'row',
        justifyContent:'space-between'
    },
    backIcon:{
        backgroundColor:'white',
        width:50,
        height:40,
        borderRadius:80,
        alignItems:'center',
        justifyContent:'center',
        marginLeft:30
    },
    filtroTextView:{
        backgroundColor:'white',
        width:80,
        height:40,
        borderRadius:10,
        alignItems:'center',
        justifyContent:'center'
    },
    filtroText:{
        fontSize:13,
        fontWeight:'bold',
        color:'black',

    }
});
export default HeaderProductByCategory;