import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import {AntDesign} from '@expo/vector-icons';

const ProductBox =({viewMode})=> {
  const arrList = [
    {
      id: 3,
      category: 'Kategori',
      productName: 'Almond Flour ',
      productImage:
        'https://images.pexels.com/photos/357573/pexels-photo-357573.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
      productPrice: '3.50€',
    },
    {
      id: 4,
      category: 'Kategori',
      productName: 'Chicken Salad',
      productImage:
        'https://images.pexels.com/photos/842571/pexels-photo-842571.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
      productPrice: '6.50€',
    },
    {
      id: 5,
      category: 'Kategori',
      productName: 'Cobb Salad',
      productImage:
        'https://images.pexels.com/photos/286283/pexels-photo-286283.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
      productPrice: '4.20€',
    },
    {
      id: 6,
      category: 'Kategori',
      productName: 'Greek Salad',
      productImage:
        'https://images.pexels.com/photos/1260968/pexels-photo-1260968.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
      productPrice: '9.00€',
    },
    {
      id: 7,
      category: 'Kategori',
      productName: 'Caesar Salad',
      productImage:
        'https://images.pexels.com/photos/1435735/pexels-photo-1435735.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
      productPrice: '1.50€',
    }
  ];
  return (
    <ScrollView>
    <View style={styles.container}>
      <FlatList
        data={arrList}
        numColumns={viewMode === "vertical" ? 2: null}
        keyExtractor={(item, index) => item.id.toString()}
        horizontal={viewMode ==="horizontal" ? true:false}
        renderItem={({item}) => {
          return (
            <View style={styles.productDetails}>
              <Image
                source={{uri: item.productImage}}
                style={styles.imageStyle}
              />
              <Text style={styles.categoryText}>{item.category}</Text>
              <Text style={styles.productName}>{item.productName}</Text>
              <Text style={styles.productPrice}>{item.productPrice}</Text>
              <View style={styles.iconView}>
                <TouchableOpacity>
                  <AntDesign name="hearto" size={20} color="green" />
                </TouchableOpacity>
                <TouchableOpacity>
                  <AntDesign name="shoppingcart" size={20} color="red" />
                </TouchableOpacity>
              </View>
            </View>
          );
        }}
      />
    </View>
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 2
  },
  imageStyle: {
    flex: 1,
    width: 145,
    height: 100,
    borderRadius: 5,
    alignSelf: "center",
  },
  productPrice: {
    fontSize: 16,
    color: 'red',
    fontWeight: 'bold',
    marginBottom: -20,
  },
  iconView: {
    flexDirection: 'row',
    alignSelf: 'flex-end',
  },
  categoryText: {
    opacity: 0.6,
    fontSize: 11,
  },
  productName: {
    fontWeight: 'bold',
    fontSize: 13,
  },
  row: {
    justifyContent: 'space-between',
  },
  productDetails: {
    flex: 1,
    padding: 5,
    margin: 5,
    borderRadius: 9,
    borderWidth: 1,
    borderColor: '#A5A4A3',
    backgroundColor: '#Fff',
    display: 'flex',
    height:280
  },
});


export default ProductBox;