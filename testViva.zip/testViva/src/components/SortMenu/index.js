import React from "react";
import {Text,View,StyleSheet} from "react-native";
import { Entypo } from "@expo/vector-icons";
import Styles from './styles';
const SortMenu = ({title})=>{
    return (
    <View style={Styles.menuTypeText}>
        <Text style={Styles.title}>{title}</Text>
        <View style={Styles.sortView}>
            <Text style={Styles.sortText}>SORTO</Text>
            <Entypo name="align-bottom" color="red" size={17}/>
        </View>
    </View>
    );
}
export default SortMenu;