import { StyleSheet } from "react-native";
export default StyleSheet.create({
    menuTypeText:{
        flexDirection:'row',
        justifyContent:'space-between',
        marginHorizontal:30,
        marginVertical:10
    },
    sortView:{
        flexDirection:'row',
        alignSelf:'center',
    },
    title:{
        fontSize:17,
        fontWeight:'bold'
    },
    sortText:{
        fontSize:14,
        fontWeight:'bold',
        color:'red'
    }
});