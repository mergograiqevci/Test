import React,{useState} from "react";
import { TextInput ,View ,StyleSheet,TouchableOpacity,Animated,Dimensions} from "react-native";
import { EvilIcons } from '@expo/vector-icons'; 

const {width}=Dimensions.get("window");
const SearchBar=({onTermChange})=>{
    const[currentSearch,setCurrentSearch]=useState("");// movie wqeqweq
    const animation=new Animated.Value(60);
    const handleClick = ()=>{
        Animated.spring(animation,{
            toValue:width*0.7,
            useNativeDriver:false,
        }).start();
    }
    return (
        <Animated.View style={{width:animation}}>
            <View style={styles.view}>
            <TextInput 
                autoFocus
                style={styles.input}
                onChangeText={newTerm=>setCurrentSearch(newTerm)}
                placeholder="Search here..." 
                placeholderTextColor="black"
                />
                
            <TouchableOpacity style={styles.icon} onPress={()=>handleClick()}>
                <View style={styles.iconView} >
                    <EvilIcons 
                        name="search" 
                        size={50} 
                        color="white" />
                </View>
            </TouchableOpacity>
            </View>
        </Animated.View>
    );
    
}

const styles=StyleSheet.create({
    view:{
        flexDirection:'row',
        borderWidth:1,
        borderColor:'#FF0000',
        borderRadius:30,
        height:50,
        width:50,
        padding:5,
        marginTop:50,
        alignSelf:'flex-end'
    },
    iconView:{
        borderRadius:30,
        height:50,
        backgroundColor:'#FF0000',
        justifyContent:'center'
    },
    icon:{
      alignSelf:'center',
      position:'absolute',
      right:0
    },
    input:{
        fontSize:18,
        flex:1,
        color:'black'
    }
});
export default SearchBar;